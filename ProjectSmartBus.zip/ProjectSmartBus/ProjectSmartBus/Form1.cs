﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace ProjectSmartBus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string ma_id;
        public Form1(string maquet_id): this()
        {
            ma_id = maquet_id;
        }
        SqlConnection con;
        

        private void Form1_Load(object sender, EventArgs e)
        {
            string conString = ConfigurationManager.ConnectionStrings["QuanLyXeBus"].ConnectionString.ToString();
            con = new SqlConnection(conString);
            con.Open();
            string s1hoten = "SELECT * FROM Account ";
            SqlCommand cmd = new SqlCommand(s1hoten, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    if (ma_id == dr[0].ToString())
                    {
                        hoten.Text = dr.GetString(1);
                        sotien.Text = dr.GetValue(2).ToString();
                        dr.Close();
                        timer1.Start();
                    }
                    
                }
            }
            
            /*
            string sql1 = "SELECT Name FROM Account WHERE ID = '" + ma_id + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            //cmd1.Parameters.Add("@maid1", SqlDbType.VarChar).Value = ma_id;
            //cmd1.ExecuteNonQuery();
            string i = (string)cmd1.ExecuteScalar();
            ttt.Text = i.ToString();
            */



        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            con.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string sql = "UPDATE Account SET Length = 1 WHERE ID = @maid";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.Add("@maid", SqlDbType.VarChar).Value = ma_id;
            cmd.ExecuteNonQuery();           
            this.Close();
        }

        

    }
}
