﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace ProjectSmartBus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string ma_id;
        public int tien_tmp;
        public Form1(string maquet_id): this()
        {
            ma_id = maquet_id;
        }
        SqlConnection con;
        

        private void Form1_Load(object sender, EventArgs e)
        {
            timer3.Start();
            string conString = ConfigurationManager.ConnectionStrings["QuanLyXeBus"].ConnectionString.ToString();
            con = new SqlConnection(conString);
            con.Open();
            string sqlhoten = "SELECT * FROM Account ";
            SqlCommand cmd = new SqlCommand(sqlhoten, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    if (ma_id == dr[0].ToString())
                    {                       
                        string s = dr.GetValue(3).ToString();
                        if (s == "0")
                        {
                            hoten.Text = dr.GetString(1);
                            sotien.Text = dr.GetValue(2).ToString();
                            timer1.Start();
                            dr.Close();  
                        }
                        else 
                        {
                            string stien = dr.GetValue(2).ToString();
                            int tien = Int32.Parse(stien) - 2000;
                            hoten.Text = dr.GetString(1);
                            sotien.Text = tien.ToString();
                            tien_tmp = tien;
                            timer2.Start();
                            dr.Close();  
                        }
                    }
                            
                }
            }
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            con.Close();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            string sql = "UPDATE Account SET Length = 1 WHERE ID = @maid";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.Add("@maid", SqlDbType.VarChar).Value = ma_id;
            cmd.ExecuteNonQuery();
            Form2 fmb2 = new Form2();
            this.Hide();
            fmb2.Show();
            
        }
        
        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            string sql1 = "UPDATE Account SET Length = 0, Money = @tien WHERE ID = @maid";
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            cmd1.Parameters.Add("@maid", SqlDbType.VarChar).Value = ma_id;
            cmd1.Parameters.Add("@tien", SqlDbType.Int).Value = tien_tmp;
            cmd1.ExecuteNonQuery();
            Form2 fmb2 = new Form2();
            this.Hide();
            fmb2.Show();
            
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            string sql1 = "UPDATE Account SET Length = 0, Money = Money-6000 WHERE Length = 1";
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            cmd1.ExecuteNonQuery();
            
        }
    }
}
