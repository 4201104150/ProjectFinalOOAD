﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Security.Cryptography;

namespace ProjectSmartBus
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection con;
        private void Form2_Load(object sender, EventArgs e)
        {
            string conString = ConfigurationManager.ConnectionStrings["QuanLyXeBus"].ConnectionString.ToString();
            con = new SqlConnection(conString);
            con.Open();
        }
        public int kiemtra(string a) 
        {
            string s1id = "SELECT ID FROM ID_Account";
            SqlCommand cmd = new SqlCommand(s1id, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    if (a == dr[0].ToString())
                    {
                        dr.Close();
                        return 1;
                    }
                }
            }
            dr.Close();
            return 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {

            
            if (kiemtra(maquet.Text) == 0) { 
                MessageBox.Show("Mời quét lại");
                maquet.Text = "";
            }
            else
            {
                /*
                //Mã hóa ID
                MD5 mh = MD5.Create();
                //Chuyển kiểu chuổi thành kiểu byte
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(maquet.Text);
                //mã hóa chuỗi đã chuyển
                byte[] hash = mh.ComputeHash(inputBytes);
                //tạo đối tượng StringBuilder (làm việc với kiểu dữ liệu lớn)
                StringBuilder sb = new StringBuilder();

                for (int i = 0; i < hash.Length; i++)
                {
                    sb.Append(hash[i].ToString("X2"));
                }
                //End Mã Hóa 
                */
                Form1 fmb = new Form1(maquet.Text);
                fmb.FormClosed += new FormClosedEventHandler(fmb_FormClosed);
                fmb.Show();
                this.Hide();
            }
        }

        private void fmb_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Show();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            con.Close();
        }
    }
}
